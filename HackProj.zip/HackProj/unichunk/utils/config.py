# Config and utility functions
import os

DATA_DIR = os.path.join(os.path.dirname(__file__), '../../Dataset')
CHROMA_DB_DIR = os.path.join(os.path.dirname(__file__), '../chroma_db')

